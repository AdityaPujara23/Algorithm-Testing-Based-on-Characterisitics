#include <iostream>
#include <chrono>
using namespace std::chrono;

extern int quicksort(int* array, int start, int end);
extern int partition(int* array, int start, int end);
extern void swap(int* array, int fill, int use);

int main() {
	double timeused;
	
	//Testing 10000 sorted elements
	int A[10000];

	for(int i = 0; i < 10000; i++) {
		A[i] = i;
	}
	
	// Turn on the timing function
    auto start = high_resolution_clock::now();

	quicksort(A,0,10000);

	// Turn off the timer and get the elapsed time
	auto stop = high_resolution_clock::now();
	auto duration = duration_cast<microseconds>(stop - start);

	std::cout<< duration.count() << std::endl;

	return 0;
}