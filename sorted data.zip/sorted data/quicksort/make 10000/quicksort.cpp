#include <iostream>
#include <math.h>


void swap(int* array, int fill, int use) {
    int temp = array[fill];
    array[fill] = array[use];
    array[use] = temp;
}

int partition(int* array, int start, int end) {
    int swap_end = start;

    for(int i = start; i < end; i++) {
        if (array[i] <= array[end] && swap_end < end) {
            swap(array,swap_end,i);
            swap_end++;
        }
    }
    swap(array,swap_end,end);
    return swap_end;
}

void quicksort(int* array, int start, int end) {
    if (start < end) {
        int partition_index = partition(array, start, end);

        quicksort(array, start, partition_index - 1);
        quicksort(array, partition_index, end);
    }
}



