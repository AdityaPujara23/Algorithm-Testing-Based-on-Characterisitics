void bubblesort(int* array, int length) {
    int temp = 0;
    for (int j = 0; j < length; j++) {
        for (int i = 0; i < length-1; i++) {
            if (array[i] > array[i+1]) {
                temp = array[i];
                array[i] = array[i+1];
                array[i+1] = temp;
            }
        }
    }
}