cd 'make 100'
./make100.sh
rm a.out
cd ..
cd 'make 1000'
./make1000.sh
rm a.out
cd ..
cd 'make 10000'
./make10000.sh
rm a.out
cd ..
clear