#include <iostream>
#include <math.h>

void merge(int first_array[],int second_array[],int array[],int length_first,int length_second) {
    int i = 0; 
    int j = 0; 
    int k = 0;

    while (i < length_first && j < length_second) {
        if (first_array[i] < second_array[j]) {
            array[k] = first_array[i];
            k++;
            i++;
        }
        else {
            array[k] = second_array[j];
            k++;
            j++;
        }
    }
    while (i < length_first) {
        array[k] = first_array[i];
        k++;
        i++;
    }
    while (j < length_second) {
        array[k] = second_array[j];
        k++;
        j++;
    }
}

void mergesort(int array[], int length) {
    if (length <= 1) {
        return;
    }

    int middle = ceil(length/2);
    int* first_array = new int[middle];
    int* second_array = new int[length - middle];

    for (int i = 0; i < middle; i++) {
        first_array[i] = array[i];
    }

    for (int i = middle; i < length; i++) {
        second_array[i - middle] = array[i];
    }

    mergesort(first_array,middle);
    mergesort(second_array,(length-middle));
    merge(first_array,second_array,array,middle,(length - middle));
    free(first_array);
    free(second_array);
}

