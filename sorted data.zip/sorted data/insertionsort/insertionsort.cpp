void insertionsort (int array[], int length) {
    if (length > 1) {
        for (int i = 1; i < length; i++) {
            int to_fill = i;
            int value = array[i];
            while (to_fill > 0 && array[to_fill-1] > value) {
                array[to_fill] = array[to_fill-1];
                to_fill--;
            }
            array[to_fill] = value;
        }
    }

}