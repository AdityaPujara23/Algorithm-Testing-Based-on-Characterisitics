#Bubble Sort
cd bubblesort
#Running tests
./bubblesort.sh
cd ..

#Insertion Sort
cd insertionsort
#Running tests
./insertionsort.sh
cd ..

#Merge Sort
cd mergesort
#Running tests
./mergesort.sh
cd ..

#Quick Sort
cd quicksort
#Running tests
./quicksort.sh
cd ..

#Selection Sort
cd selectionsort
#Running tests
./selectionsort.sh
cd ..