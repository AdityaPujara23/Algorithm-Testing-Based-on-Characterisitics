#include <iostream>
#include <chrono>
using namespace std::chrono;

extern int quicksort(int* array, int start, int end);
extern int partition(int* array, int start, int end);
extern void swap(int* array, int fill, int use);

int main() {
	double timeused;
	
	//Testing 100 unsorted elements
	srand(time(0));

	int A[100];

	for(int i=0; i < 100; i++) {
		A[i] = rand() % 101;
	}
	
	// Turn on the timing function
    auto start = high_resolution_clock::now();

	quicksort(A,0,100);

	// Turn off the timer and get the elapsed time
	auto stop = high_resolution_clock::now();
	auto duration = duration_cast<microseconds>(stop - start);

	std::cout<< duration.count() << std::endl;

	return 0;
}

