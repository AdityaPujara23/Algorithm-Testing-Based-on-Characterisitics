#include <iostream>
#include <chrono>
using namespace std::chrono;

int main() {
	double timeused;
    extern void bubblesort(int array[], int length);

	//Testing 1000 unsorted elements
	srand(time(0));

	int A[1000];

	for(int i=0; i < 1000; i++) {
		A[i] = rand() % 1001;
	}

	// Turn on the timing function
    auto start = high_resolution_clock::now();

	bubblesort(A,1000);

	// Turn off the timer and get the elapsed time
	auto stop = high_resolution_clock::now();
	auto duration = duration_cast<microseconds>(stop - start);

	std::cout<< duration.count() << std::endl;

	return 0;
}

