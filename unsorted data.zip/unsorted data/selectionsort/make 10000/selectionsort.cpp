void selectionsort(int* array, int length) {
    int temp = 0;
    for (int i =0; i < length-1; i++) {
        int current_min = i;
        for (int j = i + 1; j < length; j++) {
            if (array[j] < array[current_min]) {
                current_min = j;
            }
        }
        int temp = array[i];
        array[i] = array[current_min];
        array[current_min] = temp;
    }
}